<?php

namespace Andy\MembersRecentlyOnline\Widget;

use \XF\Widget\AbstractWidget;

class MembersRecentlyOnline extends AbstractWidget
{
    public function render()
    {
		// get options
		$options = \XF::options();
				
		// get options from Admin CP -> Options -> Members recently online -> Minutes
		$minutes = $options->membersRecentlyOnlineMinutes;
		
		// get options from Admin CP -> Options -> Members recently online -> Show avatars
		$showAvatars = $options->membersRecentlyOnlineShowAvatars;
		
		// get visitor
		$visitor = \XF::visitor();
		
		// convert to Unix timesatmp
		$timestamp = time() - (600 * $minutes);

		// get db
		$db = \XF::db();
		
		// run query
		$sessionActivity = $db->fetchAll("
			SELECT DISTINCT user_id
			FROM xf_session_activity
			WHERE user_id > ?
			AND view_state = ?
			AND view_date > ?
		", array('0', 'valid', $timestamp));
		
		// run query
		$user = $db->fetchAll("
			SELECT user_id,
			visible
			FROM xf_user
			WHERE user_id > ?
			AND last_activity > ?
			AND user_state = ?
		", array('0', $timestamp, 'valid'));
		
		// merge arrays
		$usersArray = array_unique(array_merge($sessionActivity, $user), SORT_REGULAR);

		// decalre variable
		$conditions = [];
	
		// get conditions
		foreach ($usersArray as $k => $v)
		{		
			$userId = $v['user_id'];
			$conditions[] = ['user_id', '=', $userId];
		}
		
		if (empty($conditions))
		{
			$conditions[] = ['user_id', '=', 0];
		}

		// get users
		$finder = \XF::finder('XF:User');
		$users = $finder
			->whereOr($conditions)
			->order('username', 'ASC')
			->fetch();
		
		// get total
		$total = count($users);

		// prepare ViewParams
		$viewParams = [
			'showAvatars' => $showAvatars,
			'users' => $users,
			'total' => $total
		];
			
		// send to widget
		return $this->renderer('andy_membersrecentlyonline', $viewParams);
	}

	public function getOptionsTemplate()
	{
	   return null;
	}
}