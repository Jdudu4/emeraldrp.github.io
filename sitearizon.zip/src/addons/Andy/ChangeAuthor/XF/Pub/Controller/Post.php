<?php

namespace Andy\ChangeAuthor\XF\Pub\Controller;

use XF\Mvc\ParameterBag;

class Post extends XFCP_Post
{
	public function actionChangeAuthor(ParameterBag $params)
	{
		// get visitor
		$visitor = \XF::visitor();
				
		// get permission
		if (!$visitor->hasPermission('changeAuthor', 'view'))
		{
			return $this->noPermission();
		}
		
		// get post entity
		$post = $this->assertViewablePost($params->post_id);	

		// prepare viewParams
		$viewParams = [
			'post' => $post
		];
		
		// send to template
		return $this->view('XF:Andy\ChangeAuthor', 'andy_changeauthor', $viewParams);
	}
	
	public function actionChangeAuthorSave(ParameterBag $params)
	{	
		// get visitor
		$visitor = \XF::visitor();
				
		// get permission
		if (!$visitor->hasPermission('changeAuthor', 'view'))
		{
			return $this->noPermission();
		}
		
		// get options
		$options = \XF::options();	
		
		// get options from Admin CP -> Options -> Debug options -> xfesEnabled
		@$xfesEnabled = $options->xfesEnabled;
		
		// get post entity
		$post = $this->assertViewablePost($params->post_id);		
		
		// assert post only
		$this->assertPostOnly();
		
		// get newPostAuthor
		$newPostAuthor = $this->filter('new_post_author', 'str');
		
		// get postId
		$postId = $post->post_id;
		
		// get threadId
		$threadId = $post->thread_id;				
		
		// get position
		$position = $post->position;	
		
		//########################################
		// start db operations				
		
		// get db
		$db = \XF::db();	
		
		// run query
		$result = $db->fetchRow("
		SELECT user_id,
		username
		FROM xf_user
		WHERE username = ?
		", $newPostAuthor);	
		
		// get newUserId
		$newUserId = $result['user_id'];	
		
		// if userId not found
		if ($newUserId == '')
		{
			return $this->error(\XF::phrase('requested_user_not_found'));
		}		
		
		// get newPostAuthor (corrects any case issues)
		$newPostAuthor = $result['username'];	
		
		// run query
		$oldUserId = $db->fetchOne('
		SELECT user_id
		FROM xf_post
		WHERE post_id = ?
		', $postId);
		
		//########################################
		// disallow oldUserID = newUserId
		
		if ($oldUserId == $newUserId)
		{
			return $this->error(\XF::phrase('error'));
		}
		
		//########################################
		// update xf_post and xf_thread			
		
		// run query
		$db->query("
			UPDATE xf_post SET
				user_id = ?, 
				username = ?
			WHERE post_id = ?
		", array($newUserId, $newPostAuthor, $postId));	
		
		// update if first post of thread
		if ($position == 0)
		{
			// run query
			$db->query("
				UPDATE xf_thread SET
					user_id = ?, 
					username = ?
				WHERE thread_id = ?
			", array($newUserId, $newPostAuthor, $threadId));
		}
		
		//########################################
		// update xf_forum and xf_thread
		// last post data

		// run query
		$nodeId = $db->fetchOne("
		SELECT node_id
		FROM xf_thread
		WHERE last_post_id = ?
		", $postId);
		
		// continue if last post
		if ($nodeId != '')
		{		
			// run query
			$db->query("
				UPDATE xf_forum SET
					last_post_user_id = ?,
					last_post_username = ?
				WHERE node_id = ?
			", array($newUserId, $newPostAuthor, $nodeId));				
	
			// run query
			$db->query("
				UPDATE xf_thread SET
					last_post_user_id = ?,
					last_post_username = ?
				WHERE thread_id = ?
			", array($newUserId, $newPostAuthor, $threadId));
		}
		
		//########################################
		// update xf_thread_user_post
		
		$oldUserIdPostCount = $db->fetchOne("
		SELECT COUNT(post_id)
		FROM xf_post
		WHERE thread_id = ?
		AND user_id = ?
		", array($threadId, $oldUserId));
		
		$newUserIdPostCount = $db->fetchOne("
		SELECT COUNT(post_id)
		FROM xf_post
		WHERE thread_id = ?
		AND user_id = ?
		", array($threadId, $newUserId));
		
		// delete row
		$db->query("
		DELETE FROM xf_thread_user_post
		WHERE thread_id = ?
		AND user_id = ?
		", array($threadId, $oldUserId));
		
		// delete row
		$db->query("
		DELETE FROM xf_thread_user_post
		WHERE thread_id = ?
		AND user_id = ?
		", array($threadId, $newUserId));
		
		// if condition
		if ($oldUserIdPostCount > 0)
		{
			// run query
			$db->query("
				INSERT INTO xf_thread_user_post
					(thread_id, user_id, post_count)
				VALUES 
					(?,?,?)
			", array($threadId, $oldUserId, $oldUserIdPostCount));
		}
		
		// if condition
		if ($newUserIdPostCount > 0)
		{
			// run query
			$db->query("
				INSERT INTO xf_thread_user_post
					(thread_id, user_id, post_count)
				VALUES 
					(?,?,?)
			", array($threadId, $newUserId, $newUserIdPostCount));
		}

		//########################################
		// update xf_user.message_count
		
		// check if messages are counted in this forum
		$countMessages = $db->fetchOne("
		SELECT xf_forum.count_messages
		FROM xf_post
		INNER JOIN xf_thread ON xf_thread.thread_id = xf_post.thread_id
		INNER JOIN xf_forum ON xf_forum.node_id = xf_thread.node_id
		WHERE xf_post.post_id = ?
		", $postId);
		
		// continue if countMessages
		if ($countMessages)
		{
			// run query
			$db->query("
				UPDATE xf_user
				SET message_count = message_count - 1
				WHERE user_id = ?
				AND message_count > ?
			", array($oldUserId, 0));	
			
			// run query
			$db->query("
				UPDATE xf_user
				SET message_count = message_count + 1
				WHERE user_id = ?
			", $newUserId);
		}
		
		//########################################
		// update xf_search_index
		
		if (!$xfesEnabled)
		{
			if ($position == 0)
			{
				// get metadata
				$metadata = '_md_user_' . $newUserId . ' ' . '_md_content_thread' . ' ' . '_md_node_' . $nodeId . ' ' . '_md_thread_' . $threadId;
				
				// run query
				$db->query("
					UPDATE xf_search_index
					SET user_id = ?,
					metadata = ?
					WHERE content_type = ?
					AND content_id = ?
				", array($newUserId, $metadata, 'thread', $threadId));
			}

			if ($position > 0)
			{
				// get metadata
				$metadata = '_md_user_' . $newUserId . ' ' . '_md_content_post' . ' ' . '_md_node_' . $nodeId . ' ' . '_md_thread_' . $threadId;
				
				// run query
				$db->query("
					UPDATE xf_search_index
					SET user_id = ?
					WHERE content_type = ?
					AND content_id = ?
				", array($newUserId, 'post', $postId));
			}
		}
		
		//########################################
		// update enhanced search index
		// position = 0
		//########################################
		
		// if position equals 0
		if ($xfesEnabled AND $position == 0)
		{
			$configArray = $options->xfesConfig;

			$host = $configArray['host'];
			$port = $configArray['port'];
			$index = $configArray['index'];
			
			// get _id
			$_id = 'thread-' . $threadId;
			
			//########################################
			// update index
			
			// run query
			$data = $db->fetchRow("
			SELECT xf_thread.title,
			xf_post.message,
			xf_thread.post_date,
			xf_thread.user_id,
			xf_thread.thread_id,
			xf_thread.node_id,
			xf_thread.discussion_state
			FROM xf_thread
			INNER JOIN xf_post ON xf_post.post_id = xf_thread.first_post_id
			WHERE xf_thread.thread_id = ?
			", $threadId);			
			
			if ($data['discussion_state'] == 'visible')
			{
				$hidden = false;
			}
			else
			{
				$hidden = true;
			}
			
			$dsl =  
			array(
				'title' => $data['title'],
				'message' => $data['message'],
				'date' => $data['post_date'],
				'user' => $data['user_id'],
				'discussion_id' => $threadId,
				'node' => $data['node_id'],
				'thread' => $threadId,
				'hidden' => $hidden,
				'type' => 'thread'
			);

			$json = json_encode($dsl);
			
			$url = $host . ':' . $port . '/' . $index . '/xf/' . $_id . '/';
			
			$client = \XF::app()->http()->client();	
			
            // XF 2.1
            if (\XF::options()->currentVersionId >= '2010031')
            {
				$response = $client->request('POST', $url, [
					'body' => $json,
					'headers' => [
						'Content-Type' => 'application/json',
						'Content-Length' => strlen($json),
					]
				]);
			}
			
            // XF 2.0
            if (\XF::options()->currentVersionId < '2010031')
            {
				$response = $client->createRequest('POST', 'http://' . $url, [
					'body' => $json,
					'headers' => [
						'Content-Type' => 'application/json',
						'Content-Length' => strlen($json),
					]
				]);	
				
				$client->send($response);
			}
		}
		
		//########################################
		// update enhanced search index
		// position > 0
		//########################################
		
		// if position is greater than 0
		if ($xfesEnabled AND $position > 0)
		{
			$configArray = $options->xfesConfig;

			$host = $configArray['host'];
			$port = $configArray['port'];
			$index = $configArray['index'];
			
			// get _id
			$_id = 'post-' . $postId;
			
			//########################################
			// update index
			
			// run query
			$data = $db->fetchRow("
			SELECT xf_post.message,
			xf_post.post_date,
			xf_post.user_id,
			xf_post.thread_id,
			xf_thread.node_id,
			xf_post.message_state
			FROM xf_post
			INNER JOIN xf_thread ON xf_thread.thread_id = xf_post.thread_id
			WHERE xf_post.post_id = ?
			", $postId);			
			
			if ($data['message_state'] == 'visible')
			{
				$hidden = false;
			}
			else
			{
				$hidden = true;
			}
			
			//########################################
			// start guzzle
			
            // get client
            $client = \XF::app()->http()->client();
			
			// get url
			$url = $host . ':' . $port . '/' . $index . '/xf/' . $_id . '/';
        
            // XF 2.1
            if (\XF::options()->currentVersionId >= '2010031')
            {
				$dsl =  
				array(
					'title' => '',
					'message' => $data['message'],
					'date' => $data['post_date'],
					'user' => $data['user_id'],
					'discussion_id' => $data['thread_id'],
					'node' => $data['node_id'],
					'thread' => $data['thread_id'],
					'hidden' => $hidden,
					'type' => 'post'
				);

				$json = json_encode($dsl);		

				$response = $client->request('POST', $url, [
					'body' => $json,
					'headers' => [
						'Content-Type' => 'application/json',
						'Content-Length' => strlen($json),
					]
				]);
			}
			
            // XF 2.0
            if (\XF::options()->currentVersionId < '2010031')
            {
				$dsl =  
				array(
					'title' => '',
					'message' => $data['message'],
					'date' => $data['post_date'],
					'user' => $data['user_id'],
					'discussion_id' => $data['thread_id'],
					'node' => $data['node_id'],
					'thread' => $data['thread_id'],
					'hidden' => $hidden,
					'type' => 'post'
				);

				$json = json_encode($dsl);		

				$response = $client->createRequest('POST', 'http://' . $url, [
					'body' => $json,
					'headers' => [
						'Content-Type' => 'application/json',
						'Content-Length' => strlen($json),
					]
				]);	
				
				$client->send($response);
			}
		}
		
		//########################################
		// return redirect						

		return $this->redirect(
			$this->getDynamicRedirect($this->buildLink('posts', $post), false)
		);
	}
}