<?php

return function($__templater, array $__vars, array $__options = [])
{
	$__widget = \XF::app()->widget()->widget('whats_new_new_profile_posts', $__options)->render();

	return $__widget;
};