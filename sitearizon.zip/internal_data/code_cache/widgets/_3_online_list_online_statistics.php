<?php

return function($__templater, array $__vars, array $__options = [])
{
	$__widget = \XF::app()->widget()->widget('online_list_online_statistics', $__options)->render();

	return $__widget;
};