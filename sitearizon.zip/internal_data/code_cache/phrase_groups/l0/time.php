<?php
return array (
  'time.days' => '{count} days',
  'time.hours' => '{count} hours',
  'time.minutes' => '{count} minutes',
  'time.months' => '{count} months',
  'time.seconds' => '{count} seconds',
  'time.weeks' => '{count} weeks',
  'time.years' => '{count} years',
);