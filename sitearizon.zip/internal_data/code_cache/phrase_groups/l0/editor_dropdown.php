<?php
return array (
  'editor_dropdown.xfInsert' => 'Insert',
  'editor_dropdown.xfList' => 'List',
);