<?php
return array (
  'trophy_title.1' => 'First message',
  'trophy_title.2' => 'Keeps coming back',
  'trophy_title.3' => 'Can\'t stop!',
  'trophy_title.4' => 'Addicted',
  'trophy_title.5' => 'Somebody likes you',
  'trophy_title.6' => 'I like it a lot',
  'trophy_title.7' => 'Seriously likeable!',
  'trophy_title.8' => 'Can\'t get enough of your stuff',
  'trophy_title.9' => 'I LOVE IT!',
);