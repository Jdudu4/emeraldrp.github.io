<?php
return array (
  'user_field_title.facebook' => 'Facebook',
  'user_field_title.skype' => 'Skype',
  'user_field_title.twitter' => 'Twitter',
);