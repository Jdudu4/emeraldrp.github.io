<?php
return array (
  'node_type.Category' => 'Category',
  'node_type.Forum' => 'Forum',
  'node_type.LinkForum' => 'Link forum',
  'node_type.Page' => 'Page',
);