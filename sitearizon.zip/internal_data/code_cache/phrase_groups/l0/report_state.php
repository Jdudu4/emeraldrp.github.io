<?php
return array (
  'report_state.assigned' => 'Assigned',
  'report_state.open' => 'Open',
  'report_state.rejected' => 'Rejected',
  'report_state.resolved' => 'Resolved',
);