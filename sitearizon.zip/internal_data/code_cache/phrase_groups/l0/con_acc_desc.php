<?php
return array (
  'con_acc_desc.facebook' => '',
  'con_acc_desc.github' => '',
  'con_acc_desc.google' => '',
  'con_acc_desc.linkedin' => '',
  'con_acc_desc.microsoft' => '',
  'con_acc_desc.twitter' => '',
  'con_acc_desc.yahoo' => '',
);