<?php
return array (
  'help_page_desc.bb_codes' => 'The list of BB codes you can use to spice up the look of your messages. This page shows a list of all BB codes that are available.',
  'help_page_desc.cookies' => 'This page explains how this site uses cookies.',
  'help_page_desc.privacy_policy' => 'You must accept this policy before using the site.',
  'help_page_desc.smilies' => 'This shows a full list of the smilies you can insert when posting a message.',
  'help_page_desc.terms' => 'You must agree to these terms and rules before using the site.',
  'help_page_desc.trophies' => 'You can earn trophies by carrying out different actions. This page shows a list of the trophies that are available.',
);