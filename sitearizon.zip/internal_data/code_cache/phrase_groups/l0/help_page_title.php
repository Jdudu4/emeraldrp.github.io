<?php
return array (
  'help_page_title.bb_codes' => 'BB codes',
  'help_page_title.cookies' => 'Cookie usage',
  'help_page_title.privacy_policy' => 'Privacy policy',
  'help_page_title.smilies' => 'Smilies',
  'help_page_title.terms' => 'Terms and rules',
  'help_page_title.trophies' => 'Trophies',
);