<?php
return array (
  'upgrade_check_error.no_api_key' => 'This installation does not have an API key so the upgrade check could not be completed.',
  'upgrade_check_error.no_license_for_api_key' => 'The API key for this installation does not match any existing license. Please contact XenForo support immediately.',
  'upgrade_check_error.no_valid_license_for_api_key' => 'The license being used for this installation is no longer valid. Please contact XenForo support immediately.',
);