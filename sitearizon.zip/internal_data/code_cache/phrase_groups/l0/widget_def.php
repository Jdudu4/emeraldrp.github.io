<?php
return array (
  'widget_def.birthdays' => 'Today\'s birthdays',
  'widget_def.find_member' => 'Find member',
  'widget_def.forum_statistics' => 'Forum statistics',
  'widget_def.html' => 'HTML',
  'widget_def.member_stat' => 'Member stat',
  'widget_def.members_online' => 'Members online',
  'widget_def.new_posts' => 'New posts',
  'widget_def.new_profile_posts' => 'New profile posts',
  'widget_def.new_threads' => 'New threads',
  'widget_def.newest_members' => 'Newest members',
  'widget_def.online_statistics' => 'Online statistics',
  'widget_def.php_callback' => 'PHP callback',
  'widget_def.share_page' => 'Share this page',
  'widget_def.template_syntax' => 'Template syntax',
  'widget_def.thread_poll' => 'Thread poll',
  'widget_def.visitor_panel' => 'Visitor panel',
);