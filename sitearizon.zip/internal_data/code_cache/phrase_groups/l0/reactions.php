<?php
return array (
  'reactions.1_person' => '1 person',
  'reactions.deleted_user' => '(deleted member)',
  'reactions.user1' => '{user1}',
  'reactions.user1_and_user2' => '{user1} and {user2}',
  'reactions.user1_user2_and_user3' => '{user1}, {user2} and {user3}',
  'reactions.user1_user2_user3_and_1_other' => '{user1}, {user2}, {user3} and 1 other person',
  'reactions.user1_user2_user3_and_x_others' => '{user1}, {user2}, {user3} and {others} others',
  'reactions.x_people' => '{reactions} people',
  'reactions.you' => 'You',
  'reactions.you_and_user1' => 'You and {user1}',
  'reactions.you_user1_and_user2' => 'You, {user1} and {user2}',
  'reactions.you_user1_user2_and_1_other' => 'You, {user1}, {user2} and 1 other person',
  'reactions.you_user1_user2_and_x_others' => 'You, {user1}, {user2} and {others} others',
);