<?php
return array (
  'smilie_category_title.uncategorized' => 'Смайлы без категории',
);