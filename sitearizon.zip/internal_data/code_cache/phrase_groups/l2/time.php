<?php
return array (
  'time.days' => '{count} дней',
  'time.hours' => '{count} часов',
  'time.minutes' => '{count} минут',
  'time.months' => '{count} месяцев',
  'time.seconds' => '{count} секунд',
  'time.weeks' => '{count} недель',
  'time.years' => '{count} лет',
);