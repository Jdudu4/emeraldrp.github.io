<?php
return array (
  'reaction_score.negative' => 'Отрицательно',
  'reaction_score.neutral' => 'Нейтрально',
  'reaction_score.positive' => 'Положительно',
);