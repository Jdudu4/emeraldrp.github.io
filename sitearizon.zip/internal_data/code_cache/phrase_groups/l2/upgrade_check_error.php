<?php
return array (
  'upgrade_check_error.no_api_key' => 'Эта копия XenForo не имеет ключа API, поэтому проверка обновлений не может быть завершена.',
  'upgrade_check_error.no_license_for_api_key' => 'Ключ API этой копии XenForo не соответствует существующей лицензии. Пожалуйста, немедленно обратитесь в службой поддержки XenForo.',
  'upgrade_check_error.no_valid_license_for_api_key' => 'Лицензия, используемая для этой копии XenForo, больше не действительна. Пожалуйста, немедленно обратитесь в службой поддержки XenForo.',
);