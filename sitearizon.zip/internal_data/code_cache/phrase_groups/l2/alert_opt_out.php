<?php
return array (
  'alert_opt_out.conversation_message_reaction' => 'Отреагировал на ваше сообщение в переписке',
  'alert_opt_out.post_forumwatch_insert' => 'Posts in a watched forum',
  'alert_opt_out.post_insert' => 'Ответил в отслеживаемой теме',
  'alert_opt_out.post_mention' => 'Упомянул вас в сообщении',
  'alert_opt_out.post_quote' => 'Процитировал ваще сообщение',
  'alert_opt_out.post_reaction' => 'Отреагировал на ваше сообщение',
  'alert_opt_out.profile_post_comment_other_commenter' => 'Также прокомментировал(а) сообщение профиля',
  'alert_opt_out.profile_post_comment_reaction' => 'Отреагировал на комментарий к сообщению в вашем профиле',
  'alert_opt_out.profile_post_comment_your_post' => 'Прокомментировал ваше сообщению в профиля другого пользователя',
  'alert_opt_out.profile_post_comment_your_profile' => 'Оставил комментарий на странице вашего профиля или к статусу',
  'alert_opt_out.profile_post_insert' => 'Оставил сообщение в вашем профиле',
  'alert_opt_out.profile_post_mention' => 'Упомянул вас в сообщении профиля или комментарии',
  'alert_opt_out.profile_post_reaction' => 'Отреагировал на сообщение в вашем профиле',
  'alert_opt_out.trophy_award' => 'Вы получаете новый трофей',
  'alert_opt_out.user_following' => 'Стал вашим подписчиком',
);