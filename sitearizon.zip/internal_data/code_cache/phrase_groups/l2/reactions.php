<?php
return array (
  'reactions.1_person' => '1 человек',
  'reactions.deleted_user' => '(удаленный пользователь)',
  'reactions.user1' => '{user1}',
  'reactions.user1_and_user2' => '{user1} и {user2}',
  'reactions.user1_user2_and_user3' => '{user1}, {user2} и {user3}',
  'reactions.user1_user2_user3_and_1_other' => '{user1}, {user2}, {user3} и еще 1 человек',
  'reactions.user1_user2_user3_and_x_others' => '{user1}, {user2}, {user3} и еще {others}',
  'reactions.x_people' => '{reactions} людей',
  'reactions.you' => 'Вы',
  'reactions.you_and_user1' => 'Вы и {user1}',
  'reactions.you_user1_and_user2' => 'Вы, {user1} и {user2}',
  'reactions.you_user1_user2_and_1_other' => 'Вы, {user1}, {user2} и еще 1 человек',
  'reactions.you_user1_user2_and_x_others' => 'Вы, {user1}, {user2} и еще {others}',
);