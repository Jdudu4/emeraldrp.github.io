<?php
return array (
  'api_error.api_disabled' => 'API отключен администратором.',
  'api_error.api_key_inactive' => 'Ключ API, указанный в запросе, отключен.',
  'api_error.api_key_not_found' => 'Ключ API, указанный в запросе, не найден.',
  'api_error.attachment_key_context_wrong' => 'Предоставленный ключ вложения не имеет ожидаемого контекста.',
  'api_error.attachment_key_type_wrong' => 'Предоставленный ключ вложения не имеет ожидаемого типа контента.',
  'api_error.attachment_key_unknown' => 'Предоставленный ключ вложения не найден.',
  'api_error.attachment_key_user_wrong' => 'Предоставленный ключ вложения не имеет ожидаемого пользователя.',
  'api_error.endpoint_not_found' => 'Не удается найти запрошенную конечную точку.',
  'api_error.missing_scope' => 'Для этого запроса требуется доступ к следующей области: {scope}',
  'api_error.no_api_key_in_request' => 'Ключ API не был включен в запрос.',
  'api_error.server_error_occurred' => 'Во время запроса к API произошла ошибка сервера. Пожалуйста, повторите попытку позже.',
  'api_error.user_id_not_allowed' => 'ID пользователя не может использовать этот ключ API.',
  'api_error.user_id_not_valid' => 'Указан недопустимый ID пользователя.',
);