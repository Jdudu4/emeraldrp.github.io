<?php
return array (
  'permission_interface.bookmarkPermissions' => 'Права закладок',
  'permission_interface.conversationModeratorPermissions' => 'Права модератора в личных переписках',
  'permission_interface.conversationPermissions' => 'Права личных переписок',
  'permission_interface.forumModeratorPermissions' => 'Права модератора форума',
  'permission_interface.forumPermissions' => 'Права форума',
  'permission_interface.generalModeratorPermissions' => 'Основные права модератора',
  'permission_interface.generalPermissions' => 'Основные права',
  'permission_interface.postAttachmentPermissions' => 'Права вложений',
  'permission_interface.profilePostModeratorPermissions' => 'Права модератора для сообщений в профиле',
  'permission_interface.profilePostPermissions' => 'Права для сообщений в профиле',
  'permission_interface.signaturePermissions' => 'Права подписи',
);