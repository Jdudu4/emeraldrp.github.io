<?php
return array (
  'widget_def.birthdays' => 'День рождения сегодня',
  'widget_def.find_member' => 'Найти пользователя',
  'widget_def.forum_statistics' => 'Статистика форума',
  'widget_def.html' => 'HTML',
  'widget_def.member_stat' => 'Статистика пользователей',
  'widget_def.members_online' => 'Пользователи онлайн',
  'widget_def.new_posts' => 'Новые сообщения',
  'widget_def.new_profile_posts' => 'Новые сообщения в профилях',
  'widget_def.new_threads' => 'Новые темы',
  'widget_def.newest_members' => 'Новые пользователи',
  'widget_def.online_statistics' => 'Онлайн статистика',
  'widget_def.php_callback' => 'PHP-обработчик',
  'widget_def.share_page' => 'Поделиться этой страницей',
  'widget_def.template_syntax' => 'Синтаксис шаблона',
  'widget_def.thread_poll' => 'Опрос',
  'widget_def.visitor_panel' => 'Панель посетителя',
);