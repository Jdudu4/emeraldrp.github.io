<?php
return array (
  'member_stat.highest_reaction_score' => 'Больше всех реакций',
  'member_stat.most_messages' => 'Больше всех сообщений',
  'member_stat.most_points' => 'Больше всех баллов',
  'member_stat.staff_members' => 'Члены команды',
  'member_stat.todays_birthdays' => 'День рождения сегодня',
);