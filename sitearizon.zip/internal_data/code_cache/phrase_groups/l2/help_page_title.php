<?php
return array (
  'help_page_title.bb_codes' => 'BB-коды',
  'help_page_title.cookies' => 'Использование cookie',
  'help_page_title.privacy_policy' => 'Политика конфиденциальности',
  'help_page_title.smilies' => 'Смайлы',
  'help_page_title.terms' => 'Условия и правила',
  'help_page_title.trophies' => 'Трофеи',
);