<?php
return array (
  'thread_prompt.default' => 'Заголовок темы',
);