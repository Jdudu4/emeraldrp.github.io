<?php
return array (
  'likes.1_person' => 'Понравилось одному пользователю',
  'likes.deleted_user' => '(удаленный пользователь)',
  'likes.user1' => 'Понравилось {user1}',
  'likes.user1_and_user2' => 'Понравилось {user1} и {user2}',
  'likes.user1_user2_and_user3' => 'Понравилось {user1}, {user2} и {user3}',
  'likes.user1_user2_user3_and_1_other' => 'Понравилось {user1}, {user2}, {user3} и еще одному пользователю',
  'likes.user1_user2_user3_and_x_others' => 'Понравилось {user1}, {user2}, {user3} и еще {others} пользователям',
  'likes.x_people' => 'Понравилось {likes} пользователям',
  'likes.you' => 'Понравилось вам',
  'likes.you_and_user1' => 'Понравилось вам и {user1}',
  'likes.you_user1_and_user2' => 'Понравилось вам, {user1} и {user2}',
  'likes.you_user1_user2_and_1_other' => 'Понравилось вам, {user1}, {user2} и еще одному пользователю',
  'likes.you_user1_user2_and_x_others' => 'Понравилось вам, {user1}, {user2} и {others} другим пользователям',
);