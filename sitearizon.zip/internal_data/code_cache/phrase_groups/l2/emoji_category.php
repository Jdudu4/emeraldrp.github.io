<?php
return array (
  'emoji_category.activity' => 'Активность',
  'emoji_category.flags' => 'Флаги',
  'emoji_category.food' => 'Еда',
  'emoji_category.modifier' => 'Модификаторы',
  'emoji_category.nature' => 'Природа',
  'emoji_category.objects' => 'Объекты',
  'emoji_category.people' => 'Люди',
  'emoji_category.regional' => 'Региональные',
  'emoji_category.symbols' => 'Символы',
  'emoji_category.travel' => 'Путешествия',
);