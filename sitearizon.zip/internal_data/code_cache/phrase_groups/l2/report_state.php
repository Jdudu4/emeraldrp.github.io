<?php
return array (
  'report_state.assigned' => 'Обрабатывается',
  'report_state.open' => 'Открыто',
  'report_state.rejected' => 'Отказано',
  'report_state.resolved' => 'Решено',
);