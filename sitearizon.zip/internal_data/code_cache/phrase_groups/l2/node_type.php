<?php
return array (
  'node_type.Category' => 'Категория',
  'node_type.Forum' => 'Раздел',
  'node_type.LinkForum' => 'Раздел-ссылка',
  'node_type.Page' => 'Страница',
);