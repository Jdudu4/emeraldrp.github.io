<?php
return array (
  'con_acc.facebook' => 'Facebook',
  'con_acc.github' => 'GitHub',
  'con_acc.google' => 'Google',
  'con_acc.linkedin' => 'LinkedIn',
  'con_acc.microsoft' => 'Microsoft',
  'con_acc.twitter' => 'Twitter',
  'con_acc.yahoo' => 'Yahoo',
);